This program allows a user to enter information for students and graduate students.

The program allows for file input and file output, with error checking.

This program allows the user to search through a HashMap via the entry of
a program, year and lastName which are all concatenated and converted to lower case.

This program has implemented many exceptions that will be thrown to the user
if invalid input is entered in most fields, as well as exceptions for the input file.

This program also checks for duplicate lastNames, and will prompt the user that they
have entered a duplicate last name, asking for another.


The testing input file is called:
    "read.txt"
The testing output file is called:
    "write.txt"


All output files will be placed in the LabExerciseFour package.
All input files will be read and must be read from the LabExerciseFour package.